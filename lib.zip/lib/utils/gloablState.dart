

import 'package:google_maps_flutter/google_maps_flutter.dart';

class GlobalState{
 static LatLng? pickUpLatLng;
 static String? pickUpAddress;
 static LatLng? destinationLatLng;
 static String? destinationAddress;
}